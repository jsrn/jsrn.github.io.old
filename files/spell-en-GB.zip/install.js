// Spell checking dictionary for Mozilla Thunderbird
// Script written by rockstiff. Dictionary from openoffice.org

const APP_DISPLAY_NAME	= "English (United Kingdom) dictionary";
const APP_NAME			= "spell-en-GB";
const APP_PACKAGE		= "dictionaries.mozdev.org/spell-en-GB";
const APP_VERSION		= "0.1";

var err = initInstall(APP_NAME, APP_PACKAGE, APP_VERSION);
if (err==SUCCESS) {

  // Copy files to Components/myspell
  var myspell_folder = getFolder("Components", "myspell");
  addFile(APP_NAME, "en-GB.dic", myspell_folder, "");
  addFile(APP_NAME, "en-GB.aff", myspell_folder, "");
  addFile(APP_NAME, "README-en-GB.txt", myspell_folder, "");

  err = performInstall();
  if(err == SUCCESS || err == 999) {
    alert(APP_DISPLAY_NAME+" (v "+APP_VERSION+") has been succesfully installed.\n");
  }
  else {
    alert("Installation failed. Error:" + err);
    cancelInstall(err);
  }

}
else {
  cancelInstall(err);
}

